import requests
import datetime
from config import API_FOOTBALL_KEY, RAPIDAPI_KEY

def get_today_matches_with_low_odds():
    today = datetime.datetime.utcnow().strftime('%Y-%m-%d')
    headers = { "x-apisports-key": API_FOOTBALL_KEY }
    url = f"https://v3.football.api-sports.io/fixtures?date={today}"
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        return []

    data = response.json()
    results = []
    for match in data.get("response", []):
        fixture = match["fixture"]
        league = match["league"]
        teams = match["teams"]
        match_id = fixture["id"]
        team_home = teams["home"]["name"]
        team_away = teams["away"]["name"]
        time_utc = fixture["date"][11:16]
        odds_url = f"https://api-football-v1.p.rapidapi.com/v3/odds?fixture={match_id}"
        odds_headers = {
            "X-RapidAPI-Key": RAPIDAPI_KEY,
            "X-RapidAPI-Host": "api-football-v1.p.rapidapi.com"
        }
        odds_response = requests.get(odds_url, headers=odds_headers)
        if odds_response.status_code != 200:
            continue
        odds_data = odds_response.json()
        try:
            bets = odds_data["response"][0]["bookmakers"][0]["bets"][0]["values"]
            home_odd = next((o["odd"] for o in bets if o["value"] == "Home"), None)
            if home_odd and float(home_odd) <= 1.20:
                results.append({
                    "match": f"{team_home} vs {team_away}",
                    "competition": league["name"],
                    "time": time_utc,
                    "tip": "1",
                    "odd": home_odd
                })
        except:
            continue
        if len(results) == 10:
            break
    return results
