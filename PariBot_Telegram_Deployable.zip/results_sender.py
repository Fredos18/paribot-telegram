import requests
import datetime
from config import API_FOOTBALL_KEY, TELEGRAM_API_KEY
from telebot import TeleBot

bot = TeleBot(TELEGRAM_API_KEY)

def get_today_results_and_check():
    today = datetime.datetime.utcnow().strftime('%Y-%m-%d')
    headers = { "x-apisports-key": API_FOOTBALL_KEY }
    url = f"https://v3.football.api-sports.io/fixtures?date={today}"
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        return "❌ Erreur lors de la récupération des résultats."
    data = response.json()
    results_msg = "📊 *Résultats des paris à 22h GMT*\n"
    results = []
    for match in data.get("response", []):
        fixture = match["fixture"]
        teams = match["teams"]
        goals = match["goals"]
        if fixture["status"]["short"] != "FT":
            continue
        home_name = teams["home"]["name"]
        away_name = teams["away"]["name"]
        home_goals = goals["home"]
        away_goals = goals["away"]
        score = f"{home_goals}-{away_goals}"
        outcome = "✔️" if home_goals > away_goals else "❌"
        results.append(f"{home_name} vs {away_name} ({score}) {outcome}")
    if not results:
        return "⚠️ Aucun match terminé à afficher."
    results_msg += "\n".join(results)
    return results_msg

def send_results():
    msg = get_today_results_and_check()
    bot.send_message(chat_id="@your_channel_or_user_id", text=msg, parse_mode="Markdown")
