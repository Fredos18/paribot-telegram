import time
import schedule
import telebot
from config import TELEGRAM_API_KEY
from api_coupon_generator import get_today_matches_with_low_odds

bot = telebot.TeleBot(TELEGRAM_API_KEY)

def format_coupon(coupon):
    msg = "🎯 *Coupon automatique du jour* (envoyé à 05h00 GMT+00)\n"
    msg += "🔒 Matches avec cotes ≤ 1.20 | Max 10\n\n"
    total = 1.0
    for i, match in enumerate(coupon, 1):
        msg += f"{i}. {match['match']}\n"
        msg += f"🏆 {match['competition']}\n"
        msg += f"🕒 {match['time']} GMT\n"
        msg += f"💡 Pari conseillé : {match['tip']}\n"
        msg += f"💸 Cote : {match['odd']}\n\n"
        total *= float(match['odd'])
    msg += f"📊 *Cote totale estimée* : {round(total, 2)}"
    return msg

def send_daily_coupon():
    coupon = get_today_matches_with_low_odds()
    if coupon:
        msg = format_coupon(coupon)
        bot.send_message(chat_id="@your_channel_or_user_id", text=msg, parse_mode='Markdown')
    else:
        bot.send_message(chat_id="@your_channel_or_user_id", text="⚠️ Aucun match à faible cote trouvé aujourd’hui.")

# Envoi du coupon à 05h00 GMT
schedule.every().day.at("05:00").do(send_daily_coupon)
# Envoi des résultats à 22h00 GMT
schedule.every().day.at("22:00").do(lambda: __import__("results_sender").send_results)

print("PariBot actif...")

while True:
    schedule.run_pending()
    time.sleep(30)
